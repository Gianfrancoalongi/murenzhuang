package std;
use strict;

sub in {
    print @_;
}

1;
