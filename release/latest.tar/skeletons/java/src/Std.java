package src;

public class Std 
{
    public static void in(String input) {
	System.out.println(input);
    }
}