#include "std.hpp"

#include <iostream>

namespace StdLibrary
{
   void input(const std::string& input) 
   {
     using namespace std;
     cout << input;
   }

}
