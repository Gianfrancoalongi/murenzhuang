#ifndef __STD_H__
#define __STD_H__
#include <string>

class Std {
 public:
  static void in(const std::string& );
};


#endif
