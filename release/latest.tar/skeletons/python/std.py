
def input(str):
    print str
