#pragma once
#include <string>

namespace StdLibrary
{
   void input(const std::string& input);
}
