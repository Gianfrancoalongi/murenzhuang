#include "Std.h"

#include <iostream>

void Std::in(const std::string& string) {
  std::cout << string;
}
