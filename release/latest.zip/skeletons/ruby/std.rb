
def stdin(x)
  puts x
end
