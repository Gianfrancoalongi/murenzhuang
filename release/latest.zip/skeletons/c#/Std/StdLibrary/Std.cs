﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StdLibrary
{
    public class Std
    {
        public static void input(string input)
        {
            Console.Write(input);
        }
    }
}
